#pragma once

struct GlobalVars {
	GlobalVars();

	bool gameLoop;
};