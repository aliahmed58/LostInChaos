#include "../include/Object.h"

Object::Object() {};

Object::Object(float x, float y, SDL_Renderer* gRenderer, std::string file_name, int type) {
	// set x, y coordinates and pass renderer
	this->x = x;
	this->y = y;
	this->renderer = gRenderer;
	this->type = type;
	// initialize texture by its path
	this->sprite = new Texture(file_name, renderer);
	// all objects by default have health 1
	this->health = 1;
	// by default collision rect will be the same as the complete sprite size
	this->collisionRect = { (int)x, (int)y, sprite->getWidth(), sprite->getHeight() };
	// object set to alive on creation
	alive = true;
	// angle = 0 pointing upwards by default
	angle = 0;

}

// free sprite if object is destroyed.
Object::~Object() {
	sprite->free();
}

bool Object::isAlive() {
	return alive;
}

void Object::kill(double deltaTime) {
	health--;
	if (health <= 0) alive = false;
}

void Object::render() {

	SDL_Rect src = { 0, 0, sprite->getWidth(), sprite->getHeight() };
	SDL_Rect dst = { (int) x, (int) y, sprite->getWidth(), sprite->getHeight() };
	sprite->render(&src, &dst);
}

// check if object touches wall
bool Object::wallCollision(std::array<Tile*, MAP_LENGTH>& map) {
	Tile* tile;
	SDL_Rect tileRect;
	for (int i = 0; i < map.size(); i++) {
		tile = map.at(i);
		if (tile != nullptr) {
			tileRect = tile->getRect();
			if (tile->getTileType() == 0) {
				if (checkCollision(tileRect, collisionRect, 0)) {
					return true;
				}
			}
		}
	}
	return false;
}

SDL_Rect& Object::getCollisionRect() {
	return collisionRect;
}

// move object by x and y values.
void Object::translate(float x_val, float y_val) {
	tx = x_val;
	ty = y_val;
}

int Object::getType() {
	return type;
}

float Object::getX() {
	return x;
}

float Object::getY() {
	return y;
}
