#include "../include/GlobalVars.h"

GlobalVars::GlobalVars() {
	gameLoop = false;
}